"""Admin / Users / Roles DB"""
import sqlite3, os, bcrypt
from datetime import datetime

_DB = os.environ.get("USERS_DB_PATH", os.path.join(os.path.dirname(__file__), "..", "users.db"))

def _connect():
    conn = sqlite3.connect(_DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

DEFAULT_ROLES = [
    ('Super Admin', 'Full system access — OTP on new devices; manages all users'),
    ('Admin',     'Full access to all modules'),
    ('Sir',       'Management — full ERP access'),
    ('HOD',       'Head of department — HRM module, team data only'),
    ('Employee',  'HRM module — own tasks and performance only'),
    ('Manager',   'Create/edit/approve in assigned departments'),
    ('Executive', 'Create documents; view reports'),
    ('Clerk',     'Data entry only; limited view'),
    ('Viewer',    'Read-only access to reports'),
    ('Karigar',   'Stitching production entry only (mobile floor users)'),
]

DEPARTMENTS = ['Sales', 'Merchandising', 'Stores', 'Production', 'Quality', 'Logistics', 'Finance', 'Admin']

def init_db():
    conn = _connect()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS roles (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name   TEXT UNIQUE NOT NULL,
        description TEXT,
        created_at  TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS erp_users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        username      TEXT UNIQUE NOT NULL,
        email         TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        full_name     TEXT,
        role_id       INTEGER REFERENCES roles(id),
        department    TEXT,
        active        INTEGER DEFAULT 1,
        created_at    TEXT DEFAULT (datetime('now')),
        updated_at    TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS activity_log (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id       INTEGER REFERENCES erp_users(id),
        username      TEXT,
        action        TEXT,
        document_type TEXT,
        document_no   TEXT,
        details       TEXT,
        created_at    TEXT DEFAULT (datetime('now'))
    );
    """)
    # Seed default roles
    for name, desc in DEFAULT_ROLES:
        try:
            conn.execute("INSERT OR IGNORE INTO roles(role_name,description) VALUES(?,?)", (name, desc))
        except: pass
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS login_otps (
        challenge_id  TEXT PRIMARY KEY,
        user_id       INTEGER,
        username      TEXT NOT NULL,
        phone         TEXT NOT NULL,
        code_hash     TEXT NOT NULL,
        expires_at    TEXT NOT NULL,
        verified      INTEGER DEFAULT 0,
        attempts      INTEGER DEFAULT 0,
        created_at    TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS trusted_devices (
        device_id     TEXT PRIMARY KEY,
        user_id       INTEGER,
        username      TEXT NOT NULL,
        fingerprint   TEXT NOT NULL,
        user_agent    TEXT,
        expires_at    TEXT NOT NULL,
        created_at    TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_trusted_devices_user ON trusted_devices(username, fingerprint);
    """)
    for table, col, decl in [
        ("erp_users", "karigar_id", "TEXT DEFAULT ''"),
        ("erp_users", "employee_id", "INTEGER"),
        ("erp_users", "hrm_department_id", "INTEGER"),
        ("erp_users", "reporting_hod_user_id", "INTEGER"),
        ("erp_users", "module_access", "TEXT"),
        ("erp_users", "phone", "TEXT"),
    ]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")
        except Exception:
            pass
    # Empty string counted as a value under UNIQUE(email); only one '' was allowed.
    # Normalize to NULL so many users can omit email.
    try:
        conn.execute(
            "UPDATE erp_users SET email = NULL "
            "WHERE email IS NOT NULL AND trim(email) = ''"
        )
    except Exception:
        pass
    ensure_erp_departments_seeded(conn)
    ensure_super_admin(conn)
    ensure_harsh_admin_access(conn)
    ensure_irfan_upload_account(conn)
    conn.commit(); conn.close()

# ── Super Admin bootstrap ─────────────────────────────────────────────────────
def ensure_super_admin(conn=None):
    """Ensure env admin exists in erp_users as Super Admin with phone for OTP."""
    from ..services.login_otp import normalize_india_phone

    close = False
    if conn is None:
        conn = _connect()
        close = True
    row = conn.execute("SELECT id FROM roles WHERE role_name='Super Admin'").fetchone()
    if not row:
        conn.execute(
            "INSERT OR IGNORE INTO roles(role_name,description) VALUES(?,?)",
            ("Super Admin", "Full system access — OTP on new devices; manages all users"),
        )
        row = conn.execute("SELECT id FROM roles WHERE role_name='Super Admin'").fetchone()
    if not row:
        if close:
            conn.commit()
            conn.close()
        return
    role_id = row["id"]
    username = (os.environ.get("SUPER_ADMIN_USERNAME") or os.environ.get("AUTH_USERNAME") or "admin").strip()
    phone_raw = os.environ.get("SUPER_ADMIN_PHONE", "").strip()
    phone = normalize_india_phone(phone_raw) if phone_raw else None
    pw_hash = os.environ.get("AUTH_PASSWORD_HASH", "").strip()
    if not username:
        if close:
            conn.commit()
            conn.close()
        return
    existing = conn.execute("SELECT id, phone FROM erp_users WHERE username=?", (username,)).fetchone()
    if existing:
        sets = ["role_id=?", "active=1", "updated_at=?"]
        vals = [role_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
        if phone and not (existing["phone"] or "").strip():
            sets.append("phone=?")
            vals.append(phone)
        vals.append(existing["id"])
        conn.execute(f"UPDATE erp_users SET {', '.join(sets)} WHERE id=?", vals)
    elif pw_hash:
        conn.execute(
            """INSERT INTO erp_users(username,email,password_hash,full_name,role_id,department,phone,active)
               VALUES(?,?,?,?,?,?,?,1)""",
            (
                username,
                None,
                pw_hash,
                "Super Administrator",
                role_id,
                "Admin",
                phone,
            ),
        )
        if close:
            conn.commit()
            conn.close()


_IRFAN_CANONICAL_USERNAME = "irfan"


def ensure_irfan_upload_account(conn) -> None:
    """One Irfan account (case-insensitive login) with full daily upload + PO access (Admin, no delete)."""
    canonical = _IRFAN_CANONICAL_USERNAME
    rows = conn.execute(
        """SELECT u.id, u.username, u.full_name, u.active, u.role_id, r.role_name
           FROM erp_users u LEFT JOIN roles r ON r.id = u.role_id
           WHERE lower(u.username) = lower(?)
           ORDER BY u.active DESC,
                    CASE WHEN lower(u.username) = ? THEN 0 ELSE 1 END,
                    u.id""",
        (canonical, canonical),
    ).fetchall()
    if not rows:
        return

    keeper = next((r for r in rows if r["active"] and r["username"] == canonical), None)
    if not keeper:
        keeper = next(
            (r for r in rows if r["active"] and r["username"].lower() == canonical),
            None,
        )
    if not keeper:
        keeper = next((r for r in rows if r["active"]), rows[0])

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    keeper_id = keeper["id"]
    for r in rows:
        if r["id"] != keeper_id and r["active"]:
            retired_name = f"{r['username']}_retired_{r['id']}"
            conn.execute(
                "UPDATE erp_users SET active=0, username=?, updated_at=? WHERE id=?",
                (retired_name, now, r["id"]),
            )

    admin_row = conn.execute("SELECT id FROM roles WHERE role_name='Admin'").fetchone()
    updates: dict = {}
    if keeper["username"] != canonical:
        updates["username"] = canonical
    role_name = keeper["role_name"] or ""
    if admin_row and role_name != "Super Admin":
        updates["role_id"] = admin_row["id"]
    if not (keeper["full_name"] or "").strip():
        updates["full_name"] = "Irfan"
    if updates:
        sets = ", ".join(f"{k}=?" for k in updates)
        vals = list(updates.values()) + [now, keeper_id]
        conn.execute(f"UPDATE erp_users SET {sets}, updated_at=? WHERE id=?", vals)

    ensure_user_upload_access(conn, canonical)


def ensure_user_upload_access(conn, username: str) -> None:
    """Grant daily upload + intelligence modules (Employee/HOD users who upload sales data)."""
    import json

    from ..services.rbac import resolve_module_access

    uname = (username or "").strip()
    if not uname:
        return
    upload_modules = [
        "intelligence",
        "upload",
        "sales",
        "po",
        "amazon",
        "myntra",
        "meesho",
        "flipkart",
        "snapdeal",
        "inventory",
        "sku_deepdive",
    ]
    row = conn.execute(
        """SELECT u.id, u.module_access, r.role_name
           FROM erp_users u LEFT JOIN roles r ON r.id = u.role_id
           WHERE lower(u.username) = lower(?) AND u.active = 1""",
        (uname,),
    ).fetchone()
    if not row:
        return
    current = resolve_module_access(row["role_name"] or "", row["module_access"])
    if all(m in current for m in upload_modules):
        return
    merged = sorted(set(current) | set(upload_modules))
    conn.execute(
        "UPDATE erp_users SET module_access=?, updated_at=? WHERE id=?",
        (json.dumps(merged), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), row["id"]),
    )


def ensure_user_has_modules(conn, username: str, modules: list[str]) -> None:
    """Merge module keys into a user's module_access (e.g. grant HRM to an existing ERP user)."""
    import json

    from ..services.rbac import resolve_module_access

    uname = (username or "").strip()
    if not uname or not modules:
        return
    row = conn.execute(
        """SELECT u.id, u.module_access, r.role_name
           FROM erp_users u LEFT JOIN roles r ON r.id = u.role_id
           WHERE lower(u.username) = lower(?) AND u.active = 1""",
        (uname,),
    ).fetchone()
    if not row:
        return
    current = resolve_module_access(row["role_name"] or "", row["module_access"])
    if all(m in current for m in modules):
        return
    merged = sorted(set(current) | set(modules))
    conn.execute(
        "UPDATE erp_users SET module_access=?, updated_at=? WHERE id=?",
        (json.dumps(merged), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), row["id"]),
    )


def get_role_id(role_name: str) -> int | None:
    conn = _connect()
    row = conn.execute("SELECT id FROM roles WHERE role_name=?", (role_name,)).fetchone()
    conn.close()
    return int(row["id"]) if row else None

# ── Roles ──────────────────────────────────────────────────────────────────────
def list_roles():
    conn = _connect()
    rows = conn.execute("SELECT * FROM roles ORDER BY id").fetchall()
    conn.close(); return [dict(r) for r in rows]

def create_role(role_name: str, description: str = ''):
    conn = _connect()
    conn.execute("INSERT INTO roles(role_name,description) VALUES(?,?)", (role_name, description))
    conn.commit(); conn.close()

# ── Users ──────────────────────────────────────────────────────────────────────
def list_users(active_only=True):
    conn = _connect()
    q = """SELECT u.*, r.role_name FROM erp_users u
           LEFT JOIN roles r ON r.id=u.role_id
           WHERE u.active=1 ORDER BY u.id""" if active_only else \
        "SELECT u.*, r.role_name FROM erp_users u LEFT JOIN roles r ON r.id=u.role_id ORDER BY u.id"
    rows = conn.execute(q).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d.pop('password_hash', None)  # never return hash
        result.append(d)
    conn.close(); return result


def search_active_users(q: str = "", limit: int = 100) -> list[dict]:
    """Active erp users for HR issue pickers — searchable by name/id/email/phone."""
    conn = _connect()
    sql = """SELECT u.id, u.username, u.full_name, u.email, u.phone, u.employee_id,
                    u.hrm_department_id, u.department, r.role_name
             FROM erp_users u
             LEFT JOIN roles r ON r.id=u.role_id
             WHERE u.active=1"""
    params: list = []
    term = (q or "").strip()
    if term:
        like = f"%{term.lower()}%"
        sql += """ AND (
            LOWER(COALESCE(u.full_name,'')) LIKE ?
            OR LOWER(COALESCE(u.username,'')) LIKE ?
            OR LOWER(COALESCE(u.email,'')) LIKE ?
            OR COALESCE(u.phone,'') LIKE ?
            OR CAST(u.id AS TEXT) LIKE ?
            OR CAST(COALESCE(u.employee_id,0) AS TEXT) LIKE ?
        )"""
        params.extend([like, like, like, f"%{term}%", f"%{term}%", f"%{term}%"])
    sql += " ORDER BY COALESCE(NULLIF(TRIM(u.full_name),''), u.username) LIMIT ?"
    params.append(int(limit or 100))
    rows = conn.execute(sql, tuple(params)).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        display = (d.get("full_name") or d.get("username") or f"User {d['id']}").strip()
        d["display_name"] = display
        d["search_label"] = (
            f"{display}"
            + (f" · {d['role_name']}" if d.get("role_name") else "")
            + (f" · {d['email']}" if d.get("email") else "")
            + (f" · {d['phone']}" if d.get("phone") else "")
            + (f" · EMP#{d['employee_id']}" if d.get("employee_id") else "")
        )
        out.append(d)
    return out


def get_user_by_id(uid: int) -> dict | None:
    conn = _connect()
    row = conn.execute(
        """SELECT u.*, r.role_name FROM erp_users u
           LEFT JOIN roles r ON r.id=u.role_id WHERE u.id=?""",
        (uid,),
    ).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d.pop("password_hash", None)
    return d

def _normalize_email(value) -> str | None:
    """Blank / whitespace-only email → NULL in DB (avoids UNIQUE collisions on '')."""
    if value is None:
        return None
    s = str(value).strip()
    return s if s else None


def create_user(data: dict):
    conn = _connect()
    username = (data.get("username") or "").strip()
    if not username:
        conn.close()
        raise ValueError("username is required")
    dup = conn.execute(
        "SELECT username FROM erp_users WHERE lower(username)=lower(?) AND active=1",
        (username,),
    ).fetchone()
    if dup:
        conn.close()
        raise ValueError(
            f"Username already taken (login is case-insensitive): {dup['username']}"
        )
   pw = data.get("password")
if not isinstance(pw, str) or not pw.strip():
    raise ValueError("password is required")
    hashed = bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()
    email = _normalize_email(data.get("email"))
    from ..services.login_otp import normalize_india_phone
    phone = normalize_india_phone(data.get("phone") or "") if data.get("phone") else None
    conn.execute("""INSERT INTO erp_users(
        username,email,password_hash,full_name,role_id,department,karigar_id,
        employee_id,hrm_department_id,reporting_hod_user_id,module_access,phone,active)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (username, email, hashed,
         data.get('full_name',''), data.get('role_id'), data.get('department',''),
         data.get('karigar_id', '') or '',
         data.get('employee_id'), data.get('hrm_department_id'),
         data.get('reporting_hod_user_id'), data.get('module_access'), phone,
         1))
    conn.commit(); conn.close()

def update_user(uid: int, data: dict):
    if "email" in data:
        data = {**data, "email": _normalize_email(data.get("email"))}
    allowed = [
        'email', 'full_name', 'role_id', 'department', 'active', 'karigar_id',
        'employee_id', 'hrm_department_id', 'reporting_hod_user_id', 'module_access', 'phone',
    ]
    sets = ', '.join(f"{k}=?" for k in data if k in allowed)
    vals = [data[k] for k in data if k in allowed]
    if 'password' in data:
        hashed = bcrypt.hashpw(data['password'].encode(), bcrypt.gensalt()).decode()
        sets += ', password_hash=?, updated_at=?'
        vals += [hashed, datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
    elif sets:
        sets += ', updated_at=?'
        vals += [datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
    vals += [uid]
    if not sets: return
    conn = _connect(); conn.execute(f"UPDATE erp_users SET {sets} WHERE id=?", vals)
    conn.commit(); conn.close()

def deactivate_user(uid: int):
    conn = _connect(); conn.execute("UPDATE erp_users SET active=0 WHERE id=?", (uid,))
    conn.commit(); conn.close()

def verify_erp_user(username: str, password: str):
    uname = (username or "").strip()
    if not uname:
        return None
    conn = _connect()
    row = conn.execute(
        """SELECT u.*, r.role_name FROM erp_users u
           LEFT JOIN roles r ON r.id = u.role_id
           WHERE lower(u.username)=lower(?) AND u.active=1
           ORDER BY CASE WHEN u.username=? THEN 0 ELSE 1 END, u.id
           LIMIT 1""",
        (uname, uname),
    ).fetchone()
    conn.close()
    if not row:
        return None
    if bcrypt.checkpw(password.encode(), row['password_hash'].encode()):
        d = dict(row)
        d.pop('password_hash', None)
        return d
    return None


def get_user_auth_profile(username: str) -> dict | None:
    """Load user + role for /auth/me (no password)."""
    uname = (username or "").strip()
    if not uname:
        return None
    conn = _connect()
    row = conn.execute(
        """SELECT u.id, u.username, u.email, u.full_name, u.role_id, u.department,
                  u.karigar_id, u.employee_id, u.hrm_department_id, u.reporting_hod_user_id,
                  u.module_access, u.phone, u.active, r.role_name
           FROM erp_users u
           LEFT JOIN roles r ON r.id = u.role_id
           WHERE lower(u.username)=lower(?) AND u.active=1
           ORDER BY CASE WHEN u.username=? THEN 0 ELSE 1 END, u.id
           LIMIT 1""",
        (uname, uname),
    ).fetchone()
    conn.close()
    return dict(row) if row else None

# ── ERP user departments (Admin → Users dropdown) ─────────────────────────────
def ensure_erp_departments_seeded(conn) -> None:
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS erp_departments (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT UNIQUE NOT NULL,
        active      INTEGER DEFAULT 1,
        created_at  TEXT DEFAULT (datetime('now'))
    );
    """)
    for name in DEPARTMENTS:
        try:
            conn.execute(
                "INSERT OR IGNORE INTO erp_departments(name, active) VALUES (?, 1)",
                (name.strip(),),
            )
        except Exception:
            pass


def list_erp_departments(*, active_only: bool = True) -> list[dict]:
    conn = _connect()
    ensure_erp_departments_seeded(conn)
    conn.commit()
    q = "SELECT id, name, active, created_at FROM erp_departments"
    if active_only:
        q += " WHERE active=1"
    q += " ORDER BY name COLLATE NOCASE"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def create_erp_department(name: str) -> dict:
    label = (name or "").strip()
    if not label:
        raise ValueError("Department name is required")
    if len(label) > 80:
        raise ValueError("Department name is too long (max 80 characters)")
    conn = _connect()
    ensure_erp_departments_seeded(conn)
    try:
        conn.execute(
            "INSERT INTO erp_departments(name, active) VALUES (?, 1)",
            (label,),
        )
        conn.commit()
        row = conn.execute(
            "SELECT id, name, active, created_at FROM erp_departments WHERE name=?",
            (label,),
        ).fetchone()
    except sqlite3.IntegrityError as e:
        conn.close()
        raise ValueError(f"Department “{label}” already exists") from e
    conn.close()
    return dict(row) if row else {"name": label, "active": 1}


def ensure_harsh_admin_access(conn) -> None:
    """Harsh — Admin module + Manager role for user and department management."""
    uname = "harsh"
    row = conn.execute(
        """SELECT u.id, r.role_name FROM erp_users u
           LEFT JOIN roles r ON r.id = u.role_id
           WHERE lower(u.username)=lower(?) AND u.active=1""",
        (uname,),
    ).fetchone()
    if not row:
        ensure_user_has_modules(conn, uname, ["hrm"])
        return
    mgr = conn.execute("SELECT id FROM roles WHERE role_name='Manager'").fetchone()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if mgr and (row["role_name"] or "") not in ("Super Admin", "Admin", "Manager", "Sir"):
        conn.execute(
            "UPDATE erp_users SET role_id=?, updated_at=? WHERE id=?",
            (mgr["id"], now, row["id"]),
        )
    ensure_user_has_modules(conn, uname, ["hrm", "admin"])


# ── Activity Log ───────────────────────────────────────────────────────────────
def log_activity(username: str, action: str, doc_type: str, doc_no: str, details: str = ''):
    conn = _connect()
    conn.execute("""INSERT INTO activity_log(username,action,document_type,document_no,details)
        VALUES(?,?,?,?,?)""", (username, action, doc_type, doc_no, details))
    conn.commit(); conn.close()

def list_activity(limit=100):
    conn = _connect()
    rows = conn.execute("SELECT * FROM activity_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    conn.close(); return [dict(r) for r in rows]

def get_admin_stats():
    conn = _connect()
    stats = {
        'total_users': conn.execute("SELECT COUNT(*) FROM erp_users WHERE active=1").fetchone()[0],
        'total_roles': conn.execute("SELECT COUNT(*) FROM roles").fetchone()[0],
        'recent_activity': conn.execute("SELECT COUNT(*) FROM activity_log WHERE created_at >= datetime('now','-1 day')").fetchone()[0],
        'by_role': [dict(r) for r in conn.execute("""
            SELECT r.role_name, COUNT(u.id) as cnt FROM roles r
            LEFT JOIN erp_users u ON u.role_id=r.id AND u.active=1
            GROUP BY r.id ORDER BY r.id""").fetchall()],
    }
    conn.close(); return stats


# ── OTP challenges ─────────────────────────────────────────────────────────────
def create_otp_challenge(*, challenge_id: str, user_id: int | None, username: str, phone: str,
                         code_hash: str, expires_at: str) -> None:
    conn = _connect()
    conn.execute(
        """INSERT OR REPLACE INTO login_otps
           (challenge_id, user_id, username, phone, code_hash, expires_at, verified, attempts, created_at)
           VALUES (?,?,?,?,?,?,0,0,datetime('now'))""",
        (challenge_id, user_id, username, phone, code_hash, expires_at),
    )
    conn.commit()
    conn.close()


def get_otp_challenge(challenge_id: str) -> dict | None:
    conn = _connect()
    row = conn.execute("SELECT * FROM login_otps WHERE challenge_id=?", (challenge_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def increment_otp_attempts(challenge_id: str) -> None:
    conn = _connect()
    conn.execute(
        "UPDATE login_otps SET attempts = attempts + 1 WHERE challenge_id=?",
        (challenge_id,),
    )
    conn.commit()
    conn.close()


def mark_otp_verified(challenge_id: str) -> None:
    conn = _connect()
    conn.execute("UPDATE login_otps SET verified=1 WHERE challenge_id=?", (challenge_id,))
    conn.commit()
    conn.close()


# ── Trusted devices ────────────────────────────────────────────────────────────
def register_trusted_device(*, device_id: str, user_id: int | None, username: str,
                            fingerprint: str, user_agent: str, trust_days: int) -> None:
    from datetime import timedelta, timezone
    exp = (datetime.now(tz=timezone.utc) + timedelta(days=trust_days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = _connect()
    conn.execute(
        """INSERT OR REPLACE INTO trusted_devices
           (device_id, user_id, username, fingerprint, user_agent, expires_at, created_at)
           VALUES (?,?,?,?,?,?,datetime('now'))""",
        (device_id, user_id, username, fingerprint, user_agent, exp),
    )
    conn.commit()
    conn.close()


def trusted_device_exists(*, device_id: str, username: str) -> bool:
    conn = _connect()
    row = conn.execute(
        """SELECT 1 FROM trusted_devices
           WHERE device_id=? AND username=? AND datetime(expires_at) > datetime('now')""",
        (device_id, username),
    ).fetchone()
    conn.close()
    return row is not None
